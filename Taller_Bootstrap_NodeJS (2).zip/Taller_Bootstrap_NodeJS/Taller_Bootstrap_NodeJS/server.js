const express    = require("express"); // Gestión de las peticiones HTTP
const mysql      = require('mysql'); // Gestión de la base de datos
const util = require( 'util' ); // Callbacks.

// - Inicio Configuración del servidor web

var app = express();

app.use(express.static(__dirname + '/public'));
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({extended: false,limit: '60mb'}));



app.listen(3000);
console.log('Server running at http://127.0.0.1:3000/');

// - Fin Configuración servidor web

// 
function crearConexion(){
    connection=  mysql.createConnection({
        host     : 'localhost',
        port     : '3306',
        user     : 'root',
        password : '',
        database : 'spotify'
	});
	return {
	query( sql, args ) {
		return util.promisify( connection.query )
		.call( connection, sql, args );
		},
	close() {
		return util.promisify( connection.end ).call( connection );
		}
	};
}


app.get("/getCancion", async function(req, res){
	
	console.log("en GetCancion");
	const connectionDB = crearConexion();
	var mensaje = "OK";
	try{
		const rows= await connectionDB.query('SELECT c.nombre, c.duracion, c.anio, g.nombre as genero FROM cancion c, genero g WHERE g.idGenero = c.fkgenero');
		console.log('the solution is: ', rows);
		res.json(rows);
	
	} catch ( err ) {
		console.log('Error while performing Query');
		console.log(err);
		mensaje= "NO_OK";
		res.send(mensaje);
	} finally {
		await connectionDB.close();
	}
});

app.get("/getGenero", async function(req, res){
	
	console.log("en GetGenero");
	const connectionDB = crearConexion();
	var mensaje = "OK";
	try{
		const rows= await connectionDB.query('SELECT g.idGenero, g.nombre FROM  genero g');
		console.log('the solution is: ', rows);
		res.json(rows);
	
	} catch ( err ) {
		console.log('Error while performing Query');
		console.log(err);
		mensaje= "NO_OK";
		res.send(mensaje);
	} finally {
		await connectionDB.close();
	}
});

app.post("/insertCancion", async function(req,res){
	let mensaje="OK";
	const bodyInformation = req.body;
	console.log(bodyInformation);
	var cancion={
		nombre: bodyInformation.nombre,
		duracion: bodyInformation.duracion,
		anio: bodyInformation.anio,
		fkgenero: bodyInformation.genero
	}
	const connectionDB = crearConexion();
	
	try{
		const results = await connectionDB.query("INSERT INTO cancion SET ?", cancion);
		console.log("insertado");
	} catch ( err ) {
		console.log('Error while performing Query');
		console.log(err);
		mensaje= "NO_OK";
	} finally {
		await connectionDB.close();
		res.send(mensaje);
	}
});




