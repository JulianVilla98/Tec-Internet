<?php
require_once ('../config/ConnectionDB.php');

class GeneroDAO {
   
   private $connectionDB;
   private $dbCon;
   const CONSULTA = "SELECT g.idGenero, g.nombre FROM  genero g";
   
   public function __construct() {
     $this->connectionDB = new connectionDB();
     $this->dbCon = $this->connectionDB->getConnection();
   }

   public function readAll() {
      try {
         $statement = $this->dbCon->prepare(self::CONSULTA);
         $statement->execute();
         $cancion = $statement->fetchAll(PDO::FETCH_ASSOC);
			
      }catch(PDOException $ex){
         echo $ex->getMessage();
         die($ex->getMessage());
      }
      return $cancion;
      $this->connectionDB.close();
   }
}
?>