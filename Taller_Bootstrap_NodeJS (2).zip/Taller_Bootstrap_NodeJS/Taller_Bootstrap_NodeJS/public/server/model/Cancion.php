<?php

class Cancion {

    var $idCancion;
    var $nombre;
    var $duracion;
    var $anio;
    var $genero;

    function __construct($nombre, $duracion, $anio, $genero)
    {
        $this->nombre = $nombre;
        $this->duracion = $duracion;
        $this->anio = $anio;
        $this->genero = $genero;
    }
    

}
?>