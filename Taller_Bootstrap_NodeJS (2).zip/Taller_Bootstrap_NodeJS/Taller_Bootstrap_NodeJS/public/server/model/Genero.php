<?php

class Genero {

    var $idGenero;
    var $nombre;

    function __construct($nombre, $duracion, $anio, $genero)
    {
        $this->nombre = $nombre;
        $this->idGenero = $genero;
    }
}
?>