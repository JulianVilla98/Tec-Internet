<?php
    require_once ('../daos/GeneroDAO.php');
    $generoDAO = new GeneroDAO();
    $results= json_encode($generoDAO->readAll());
    echo $results;
?>