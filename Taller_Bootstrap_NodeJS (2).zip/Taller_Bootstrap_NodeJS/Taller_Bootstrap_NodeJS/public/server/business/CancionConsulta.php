<?php
    require_once ('../daos/CancionDAO.php');
    $cancionDAO = new CancionDAO();
    $results= json_encode($cancionDAO->readAll());
    echo $results;
?>