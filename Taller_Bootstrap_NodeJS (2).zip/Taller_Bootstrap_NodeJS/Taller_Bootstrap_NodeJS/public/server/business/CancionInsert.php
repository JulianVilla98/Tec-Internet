<?php
    require_once ('../Daos/CancionDAO.php');
    
    $cuerpo = file_get_contents('php://input');
    $cancionDTO = json_decode($cuerpo);

    $cancionDAO = new CancionDAO();
    $cancion = new Cancion($cancionDTO->nombre,$cancionDTO->duracion,$cancionDTO->anio,$cancionDTO->genero);
    $results = $cancionDAO->create($cancion);
    echo $results;
?>