<?php

$servername= "localhost:3306"; 
$username ="root";
$password ="";
$dbname ="spotify";

//crear conexión
$conn=new mysqli ($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "utf8");
//validar conexión 
if($conn->connect_error){
	die("connection failed: ".$conn->connect_error);
}

mysqli_set_charset($conn,"utf8");
$cuerpo=file_get_contents('php://input');
$pelicula=json_decode($cuerpo);
//
//

$sql="UPDATE Pelicula_G SET nombre='".$pelicula->nombreNuevo."' WHERE PK_ID_pelicula=1" ;

//("."'".$pelicula->nombre."'".",'".$pelicula->descripcion."'".",2)";
//ejecutar consulta
$result=$conn->query($sql);
if($result){
	//echo "New record created successfully";
	echo "OK";
	//File_ot_contents ('php://stderr', print_r ("New record created successfully", TRUE));
}else{
	//$foo="Error";
	error_log(print_r(mysqli_error($conn), TRUE), 0);
	ECHO "Error: ", $sql."<br>".mysqli_error($conn);
}

$conn->close();
?>